Attributes {
    NC_GLOBAL {
        String title "MERRA2_GMI tavg1_2d_flx_Nx: 2d,1-Hourly,Time-Averaged,Single-Level,Replay,Surface Flux Diagnostics";
        String Conventions "COARDS", "GrADS";
        String dataType "Grid";
        String history "Fri Nov 06 10:18:11 EST 2026 : imported by GrADS Data Server 2.0";
        String extra_das_attribute "This is an example of metadata added using a supplementary DAS file. See testdata/extra.das for the source.";
    }
    var_precsno {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_precsno ";
    }
    risfc {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_bulk_richardson_number ";
    }
    var_evap {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evap ";
    }
    rhoa {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "air_density_at_surface ";
    }
    var_ustar {
        String units "m s-1 m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ustar ";
    }
    var_qlml {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_qlml ";
    }
    var_disph {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_disph ";
    }
    speed {
        String units "m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_wind_speed ";
    }
    precsno {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "snowfall ";
    }
    frccn {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "areal_fraction_of_convective_showers ";
    }
    evap {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "evaporation_from_turbulence ";
    }
    ghtskin {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ground_heating_for_skin_temp ";
    }
    prevtot {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_column_re-evap/subl_of_precipitation ";
    }
    var_z0m {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_z0m ";
    }
    z0h {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_roughness_for_heat ";
    }
    var_nirdf {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nirdf ";
    }
    preclsc {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nonanvil_large_scale_precipitation ";
    }
    var_nirdr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nirdr ";
    }
    var_speedmax {
        String units "m s-1 m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_speedmax ";
    }
    pblh {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "planetary_boundary_layer_height ";
    }
    eflux {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_latent_energy_flux ";
    }
    tczpbl {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "transcom_planetary_boundary_layer_height ";
    }
    var_taugwy {
        String units "N m-2 N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_taugwy ";
    }
    taux {
        String units "N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "eastward_surface_stress ";
    }
    cn {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_neutral_drag_coefficient ";
    }
    var_speed {
        String units "m s-1 m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_speed ";
    }
    var_frseaice {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frseaice ";
    }
    cdh {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_exchange_coefficient_for_heat ";
    }
    var_ulml {
        String units "m s-1 m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ulml ";
    }
    var_tsh {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsh ";
    }
    var_tlml {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tlml ";
    }
    var_frcan {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frcan ";
    }
    pgentot {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_column_production_of_precipitation ";
    }
    var_taugwx {
        String units "N m-2 N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_taugwx ";
    }
    tstar {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_scale ";
    }
    bstar {
        String units "m s-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_buoyancy_scale ";
    }
    var_evapout {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evapout ";
    }
    prectotcorr {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_precipitation ";
    }
    qlml {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_specific_humidity ";
    }
    hflux {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sensible_heat_flux_from_turbulence ";
    }
    var_ghtskin {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ghtskin ";
    }
    var_tauy {
        String units "N m-2 N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tauy ";
    }
    prectot {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_precipitation ";
    }
    var_cn {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cn ";
    }
    var_vlml {
        String units "m s-1 m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_vlml ";
    }
    var_qsh {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_qsh ";
    }
    precanv {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "anvil_precipitation ";
    }
    var_pblh {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pblh ";
    }
    ulml {
        String units "m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_eastward_wind ";
    }
    var_hflux {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_hflux ";
    }
    tauy {
        String units "N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "northward_surface_stress ";
    }
    evapout {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "evaporation ";
    }
    var_rhoa {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_rhoa ";
    }
    var_pgentot {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pgentot ";
    }
    preccon {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "convective_precipitation ";
    }
    qstar {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_moisture_scale ";
    }
    var_frccn {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frccn ";
    }
    nirdf {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_downwelling_nearinfrared_diffuse_flux ";
    }
    tsh {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "effective_surface_skin_temperature ";
    }
    var_bstar {
        String units "m s-2 m s-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bstar ";
    }
    cdm {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_exchange_coefficient_for_momentum ";
    }
    cdq {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_exchange_coefficient_for_moisture ";
    }
    frcan {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "areal_fraction_of_anvil_showers ";
    }
    var_qstar {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_qstar ";
    }
    var_prevtot {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_prevtot ";
    }
    taugwy {
        String units "N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_northward_gravity_wave_stress ";
    }
    disph {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "zero_plane_displacement_height ";
    }
    var_tstar {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tstar ";
    }
    hlml {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_layer_height ";
    }
    var_frcls {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frcls ";
    }
    var_preccon {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_preccon ";
    }
    var_cdh {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cdh ";
    }
    var_risfc {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_risfc ";
    }
    var_cdm {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cdm ";
    }
    var_shout {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_shout ";
    }
    var_preclsc {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_preclsc ";
    }
    ustar {
        String units "m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_velocity_scale ";
    }
    var_cdq {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cdq ";
    }
    frseaice {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ice_covered_fraction_of_tile ";
    }
    speedmax {
        String units "m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_wind_speed ";
    }
    qsh {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "effective_surface_specific_humidity ";
    }
    var_taux {
        String units "N m-2 N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_taux ";
    }
    var_prectotcorr {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_prectotcorr ";
    }
    var_eflux {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_eflux ";
    }
    shout {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "upward_sensible_heat_flux ";
    }
    vlml {
        String units "m s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_northward_wind ";
    }
    var_prectot {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_prectot ";
    }
    var_precanv {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_precanv ";
    }
    var_tczpbl {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tczpbl ";
    }
    taugwx {
        String units "N m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_eastward_gravity_wave_stress ";
    }
    tlml {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_air_temperature ";
    }
    z0m {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_roughness ";
    }
    var_hlml {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_hlml ";
    }
    nirdr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_downwelling_nearinfrared_beam_flux ";
    }
    var_z0h {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_z0h ";
    }
    frcls {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "areal_fraction_of_nonanvil_large_scale_showers ";
    }
    lon {
        String grads_dim "x";
        String grads_mapping "linear";
        String grads_size "576";
        String units "degrees_east";
        String long_name "longitude";
        Float64 minimum -180.00000000000;
        Float64 maximum 179.37500000000;
        Float32 resolution 0.625;
    }
    lat {
        String grads_dim "y";
        String grads_mapping "linear";
        String grads_size "361";
        String units "degrees_north";
        String long_name "latitude";
        Float64 minimum -90.00000000000;
        Float64 maximum 90.00000000000;
        Float32 resolution 0.5;
    }
    time {
        String grads_dim "t";
        String grads_mapping "linear";
        String grads_size "480";
        String grads_min "00z15jan1980";
        String grads_step "1mo";
        String units "days since 1-1-1 00:00:0.0";
        String long_name "time";
        String minimum "00z15jan1980";
        String maximum "00z15dec2019";
        Float32 resolution 30.436325;
    }
}
