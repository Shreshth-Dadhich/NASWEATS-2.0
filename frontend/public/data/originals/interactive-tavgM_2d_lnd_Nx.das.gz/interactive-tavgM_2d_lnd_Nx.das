Attributes {
    NC_GLOBAL {
        String title "MERRA2_GMI tavg1_2d_lnd_Nx: 2d,1-Hourly,Time-Averaged,Single-Level,Replay,Land Surface Diagnostics";
        String Conventions "COARDS", "GrADS";
        String dataType "Grid";
        String history "Mon Sep 28 16:14:31 EDT 2026 : imported by GrADS Data Server 2.0";
        String extra_das_attribute "This is an example of metadata added using a supplementary DAS file. See testdata/extra.das for the source.";
    }
    tsurf {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_of_land_incl_snow ";
    }
    var_gwetprof {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_gwetprof ";
    }
    tsat {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_of_saturated_zone ";
    }
    spsnow {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "rate_of_spurious_snow_energy ";
    }
    var_twlt {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_twlt ";
    }
    var_lhland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lhland ";
    }
    var_grn {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_grn ";
    }
    lhland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "latent_heat_flux_land ";
    }
    var_spland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_spland ";
    }
    var_gwetroot {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_gwetroot ";
    }
    var_baseflow {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_baseflow ";
    }
    var_prmc {
        String units "m-3 m-3 m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_prmc ";
    }
    smland {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "snowmelt_flux_land ";
    }
    baseflow {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "baseflow_flux ";
    }
    lwland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "net_longwave_land ";
    }
    frsat {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "fractional_area_of_saturated_zone ";
    }
    tsoil3 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_3 ";
    }
    tsoil4 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_4 ";
    }
    var_twland {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_twland ";
    }
    var_pardfland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pardfland ";
    }
    var_tpsnow {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tpsnow ";
    }
    var_tsoil4 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil4 ";
    }
    var_ghland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ghland ";
    }
    snomas {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_snow_storage_land ";
    }
    var_evpsbln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evpsbln ";
    }
    swland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "net_shortwave_land ";
    }
    var_tsurf {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsurf ";
    }
    var_tsoil3 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil3 ";
    }
    prectotland {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_precipitation_land ";
    }
    shland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sensible_heat_flux_land ";
    }
    twlt {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_of_wilted_zone ";
    }
    var_rzmc {
        String units "m-3 m-3 m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_rzmc ";
    }
    echange {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "rate_of_change_of_total_land_energy ";
    }
    runoff {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "overland_runoff_including_throughflow ";
    }
    teland {
        String units "J m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_energy_storage_land ";
    }
    tpsnow {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_of_snow ";
    }
    var_swland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swland ";
    }
    var_snomas {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_snomas ";
    }
    var_sfmc {
        String units "m-3 m-3 m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sfmc ";
    }
    var_tsoil5 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil5 ";
    }
    var_shland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_shland ";
    }
    var_runoff {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_runoff ";
    }
    var_snodp {
        String units "m m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_snodp ";
    }
    tunst {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_temperature_of_unsaturated_zone ";
    }
    evland {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "evaporation_land ";
    }
    var_spwatr {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_spwatr ";
    }
    tsoil1 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_1 ";
    }
    pardfland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_downwelling_par_diffuse_flux ";
    }
    var_tsat {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsat ";
    }
    var_teland {
        String units "J m-2 J m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_teland ";
    }
    var_qinfil {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_qinfil ";
    }
    gwettop {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_soil_wetness ";
    }
    var_spsnow {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_spsnow ";
    }
    evpsoil {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "baresoil_evap_energy_flux ";
    }
    var_smland {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_smland ";
    }
    var_frsat {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frsat ";
    }
    var_evland {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evland ";
    }
    var_frsno {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frsno ";
    }
    var_evpintr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evpintr ";
    }
    frsno {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "fractional_area_of_land_snowcover ";
    }
    sfmc {
        String units "m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "water_surface_layer ";
    }
    ghland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ground_heating_land ";
    }
    pardrland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_downwelling_par_beam_flux ";
    }
    spland {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "rate_of_spurious_land_energy_source ";
    }
    twland {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "avail_water_storage_land ";
    }
    lai {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "leaf_area_index ";
    }
    gwetprof {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ave_prof_soil_moisture ";
    }
    gwetroot {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "root_zone_soil_wetness ";
    }
    precsnoland {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "snowfall_land ";
    }
    qinfil {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_water_infiltration_rate ";
    }
    var_pardrland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pardrland ";
    }
    var_lai {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lai ";
    }
    evptrns {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "transpiration_energy_flux ";
    }
    tsoil6 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_6 ";
    }
    var_frunst {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frunst ";
    }
    grn {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "greenness_fraction ";
    }
    prmc {
        String units "m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "water_profile ";
    }
    var_frwlt {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_frwlt ";
    }
    var_evptrns {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evptrns ";
    }
    var_gwettop {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_gwettop ";
    }
    spwatr {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "rate_of_spurious_land_water_source ";
    }
    rzmc {
        String units "m-3 m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "water_root_zone ";
    }
    tsoil2 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_2 ";
    }
    frunst {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "fractional_area_of_unsaturated_zone ";
    }
    var_lwland {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwland ";
    }
    var_echange {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_echange ";
    }
    var_tunst {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tunst ";
    }
    var_tsoil2 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil2 ";
    }
    evpsbln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "snow_ice_evaporation_energy_flux ";
    }
    evpintr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "interception_loss_energy_flux ";
    }
    tsoil5 {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "soil_temperatures_layer_5 ";
    }
    var_wchange {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_wchange ";
    }
    var_tsoil1 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil1 ";
    }
    var_prectotland {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_prectotland ";
    }
    var_tsoil6 {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tsoil6 ";
    }
    wchange {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "rate_of_change_of_total_land_water ";
    }
    var_precsnoland {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_precsnoland ";
    }
    var_evpsoil {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_evpsoil ";
    }
    snodp {
        String units "m";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "snow_depth ";
    }
    frwlt {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "fractional_area_of_wilting_zone ";
    }
    lon {
        String grads_dim "x";
        String grads_mapping "linear";
        String grads_size "576";
        String units "degrees_east";
        String long_name "longitude";
        Float64 minimum -180.00000000000;
        Float64 maximum 179.37500000000;
        Float32 resolution 0.625;
    }
    lat {
        String grads_dim "y";
        String grads_mapping "linear";
        String grads_size "361";
        String units "degrees_north";
        String long_name "latitude";
        Float64 minimum -90.00000000000;
        Float64 maximum 90.00000000000;
        Float32 resolution 0.5;
    }
    time {
        String grads_dim "t";
        String grads_mapping "linear";
        String grads_size "480";
        String grads_min "00z15jan1980";
        String grads_step "1mo";
        String units "days since 1-1-1 00:00:0.0";
        String long_name "time";
        String minimum "00z15jan1980";
        String maximum "00z15dec2019";
        Float32 resolution 30.436325;
    }
}
