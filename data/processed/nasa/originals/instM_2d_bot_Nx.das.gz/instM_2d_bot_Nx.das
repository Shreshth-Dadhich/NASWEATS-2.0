Attributes {
    NC_GLOBAL {
        String title "MERRA2_GMI inst1_2d_bot_Nx: 2d,1-Hourly,Instantaneous,Single-Level,Replay,Bottom Layer Diagnostics";
        String Conventions "COARDS", "GrADS";
        String dataType "Grid";
        String history "Fri Nov 06 10:27:09 EST 2026 : imported by GrADS Data Server 2.0";
        String extra_das_attribute "This is an example of metadata added using a supplementary DAS file. See testdata/extra.das for the source.";
    }
    so4mass_bot {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 aerosol mass mixing ratio __ensemble__ ";
    }
    pm25_bot {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total reconstructed pm2.5 ";
    }
    var_nimass_bot {
        String units "kg/kg kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nimass_bot ";
    }
    var_so4massvolc {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4massvolc_bot ";
    }
    t_bot {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "air_temperature ";
    }
    nimass25_bot {
        String units "kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate mass mixing ratio [pm2.5] __ensemble__ ";
    }
    var_dumass25_bo {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dumass25_bot ";
    }
    var_nimass25_bo {
        String units "kg/kg kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nimass25_bot ";
    }
    sto3_bot {
        String units "mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "strat ozone w/ loss in troposphere ";
    }
    pl_bot {
        String units "Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "mid_level_pressure ";
    }
    o3_bot {
        String units "mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ozone ";
    }
    var_ps {
        String units "Pa Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ps ";
    }
    ps {
        String units "Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_pressure ";
    }
    bcmass_bot {
        String units "kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon mass mixing ratio __ensemble__ ";
    }
    var_ssmass25_bo {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssmass25_bot ";
    }
    so4massvolc_bot {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 aerosol mass mixing ratio (volcanic) ";
    }
    var_sto3_bot {
        String units "mol mol-1 mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sto3_bot ";
    }
    var_co_bot {
        String units "mol mol-1 mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_co_bot ";
    }
    var_pm_bot {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pm_bot ";
    }
    ocmass_bot {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon mass mixing ratio __ensemble__ ";
    }
    var_dd_o3_bot {
        String units "kg m-2 s-1 kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dd_o3_bot ";
    }
    delp_bot {
        String units "Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "pressure_thickness ";
    }
    var_t_bot {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_t_bot ";
    }
    var_pm25_bot {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pm25_bot ";
    }
    var_o3_bot {
        String units "mol mol-1 mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_o3_bot ";
    }
    var_no2_bot {
        String units "mol mol-1 mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_no2_bot ";
    }
    no_bot {
        String units "mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitric oxide ";
    }
    var_pl_bot {
        String units "Pa Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pl_bot ";
    }
    ssmass25_bot {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt mass mixing ratio - pm 2.5 ";
    }
    pm_bot {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total reconstructed pm ";
    }
    no2_bot {
        String units "mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrogen dioxide ";
    }
    dumass25_bot {
        String units "kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust mass mixing ratio - pm 2.5 ";
    }
    var_so4mass_bot {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4mass_bot ";
    }
    var_no_bot {
        String units "mol mol-1 mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_no_bot ";
    }
    nimass_bot {
        String units "kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate mass mixing ratio __ensemble__ ";
    }
    var_delp_bot {
        String units "Pa Pa";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_delp_bot ";
    }
    var_ocmass_bot {
        String units "kg kg-1 kg kg-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocmass_bot ";
    }
    dd_o3_bot {
        String units "kg m-2 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dry_deposition_of_ox ";
    }
    var_bcmass_bot {
        String units "kg/kg kg/kg";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcmass_bot ";
    }
    co_bot {
        String units "mol mol-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "carbon monoxide ";
    }
    lon {
        String grads_dim "x";
        String grads_mapping "linear";
        String grads_size "576";
        String units "degrees_east";
        String long_name "longitude";
        Float64 minimum -180.00000000000;
        Float64 maximum 179.37500000000;
        Float32 resolution 0.625;
    }
    lat {
        String grads_dim "y";
        String grads_mapping "linear";
        String grads_size "361";
        String units "degrees_north";
        String long_name "latitude";
        Float64 minimum -90.00000000000;
        Float64 maximum 90.00000000000;
        Float32 resolution 0.5;
    }
    time {
        String grads_dim "t";
        String grads_mapping "linear";
        String grads_size "480";
        String grads_min "00z15jan1980";
        String grads_step "1mo";
        String units "days since 1-1-1 00:00:0.0";
        String long_name "time";
        String minimum "00z15jan1980";
        String maximum "00z15dec2019";
        Float32 resolution 30.436325;
    }
    lev {
        String grads_dim "z";
        String grads_mapping "linear";
        String units "millibar";
        String long_name "altitude";
        Float64 minimum 0.00000000000;
        Float64 maximum 0.00000000000;
    }
}
