Attributes {
    NC_GLOBAL {
        String title "MERRA2_GMI tavg1_2d_rad_Nx: 2d,1-Hourly,Time-Averaged,Single-Level,Replay,Radiation Diagnostics";
        String Conventions "COARDS", "GrADS";
        String dataType "Grid";
        String history "Fri Nov 06 10:26:47 EST 2026 : imported by GrADS Data Server 2.0";
        String extra_das_attribute "This is an example of metadata added using a supplementary DAS file. See testdata/extra.das for the source.";
    }
    var_lwgabclrcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgabclrcln ";
    }
    swgdnclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_incoming_shortwave_flux_assuming_clear_sky ";
    }
    lwgabclrcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_absorbed_longwave_radiation_assuming_clear_sky_and_no_aerosol ";
    }
    var_cldmid {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cldmid ";
    }
    var_swtntcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swtntcln ";
    }
    var_cldtot {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cldtot ";
    }
    var_albnirdr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_albnirdr ";
    }
    var_tautot {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tautot ";
    }
    ts {
        String units "K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_skin_temperature ";
    }
    var_albedo {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_albedo ";
    }
    var_swtnt {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swtnt ";
    }
    cldhgh {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "cloud_area_fraction_for_high_clouds ";
    }
    var_emis {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_emis ";
    }
    emis {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_emissivity ";
    }
    var_swtntclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swtntclr ";
    }
    tautot {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "in_cloud_optical_thickness_of_all_clouds ";
    }
    swgntclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_shortwave_flux_assuming_clear_sky ";
    }
    albedo {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_albedo ";
    }
    lwtup {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "upwelling_longwave_flux_at_toa ";
    }
    var_swgntclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgntclr ";
    }
    var_swgntcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgntcln ";
    }
    var_albnirdf {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_albnirdf ";
    }
    taulow {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "in_cloud_optical_thickness_of_low_clouds ";
    }
    lwgntclrcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_longwave_flux_assuming_clear_sky_and_no_aerosol ";
    }
    swtnt {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "toa_net_downward_shortwave_flux ";
    }
    var_swtdn {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swtdn ";
    }
    var_swgntclrcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgntclrcln ";
    }
    var_lwtup {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwtup ";
    }
    var_cldlow {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cldlow ";
    }
    lwgnt {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_longwave_flux ";
    }
    var_swgnt {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgnt ";
    }
    var_taulow {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_taulow ";
    }
    albnirdr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_albedo_for_near_infrared_beam ";
    }
    albvisdr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_albedo_for_visible_beam ";
    }
    swgntclrcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_shortwave_flux_assuming_clear_sky_and_no_aerosol ";
    }
    lwtupclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "upwelling_longwave_flux_at_toa_assuming_clear_sky ";
    }
    lwgab {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_absorbed_longwave_radiation ";
    }
    var_tauhgh {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_tauhgh ";
    }
    var_taumid {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_taumid ";
    }
    albvisdf {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_albedo_for_visible_diffuse ";
    }
    var_lwgab {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgab ";
    }
    swgntcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_shortwave_flux_assuming_no_aerosol ";
    }
    var_lwgntclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgntclr ";
    }
    var_albvisdf {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_albvisdf ";
    }
    lwtupclrcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "upwelling_longwave_flux_at_toa_assuming_clear_sky_and_no_aerosol ";
    }
    var_swgdn {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgdn ";
    }
    cldtot {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total_cloud_area_fraction ";
    }
    var_lwgnt {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgnt ";
    }
    swgnt {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_shortwave_flux ";
    }
    cldlow {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "cloud_area_fraction_for_low_clouds ";
    }
    albnirdf {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_albedo_for_near_infrared_diffuse ";
    }
    var_lwtupclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwtupclr ";
    }
    swtntclrcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "toa_net_downward_shortwave_flux_assuming_clear_sky_and_no_aerosol ";
    }
    swtntcln {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "toa_net_downward_shortwave_flux_assuming_no_aerosol ";
    }
    var_albvisdr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_albvisdr ";
    }
    var_lwgabclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgabclr ";
    }
    var_swtntclrcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swtntclrcln ";
    }
    var_lwtupclrcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwtupclrcln ";
    }
    lwgem {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "longwave_flux_emitted_from_surface ";
    }
    var_ts {
        String units "K K";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ts ";
    }
    var_lwgem {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgem ";
    }
    swtntclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "toa_net_downward_shortwave_flux_assuming_clear_sky ";
    }
    lwgntclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_net_downward_longwave_flux_assuming_clear_sky ";
    }
    taumid {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "in_cloud_optical_thickness_of_middle_clouds ";
    }
    var_cldhgh {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_cldhgh ";
    }
    var_swgdnclr {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_swgdnclr ";
    }
    lwgabclr {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_absorbed_longwave_radiation_assuming_clear_sky ";
    }
    tauhgh {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "in_cloud_optical_thickness_of_high_clouds(export) ";
    }
    swtdn {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "toa_incoming_shortwave_flux ";
    }
    swgdn {
        String units "W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "surface_incoming_shortwave_flux ";
    }
    var_lwgntclrcln {
        String units "W m-2 W m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_lwgntclrcln ";
    }
    cldmid {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "cloud_area_fraction_for_middle_clouds ";
    }
    lon {
        String grads_dim "x";
        String grads_mapping "linear";
        String grads_size "576";
        String units "degrees_east";
        String long_name "longitude";
        Float64 minimum -180.00000000000;
        Float64 maximum 179.37500000000;
        Float32 resolution 0.625;
    }
    lat {
        String grads_dim "y";
        String grads_mapping "linear";
        String grads_size "361";
        String units "degrees_north";
        String long_name "latitude";
        Float64 minimum -90.00000000000;
        Float64 maximum 90.00000000000;
        Float32 resolution 0.5;
    }
    time {
        String grads_dim "t";
        String grads_mapping "linear";
        String grads_size "480";
        String grads_min "00z15jan1980";
        String grads_step "1mo";
        String units "days since 1-1-1 00:00:0.0";
        String long_name "time";
        String minimum "00z15jan1980";
        String maximum "00z15dec2019";
        Float32 resolution 30.436325;
    }
}
