Attributes {
    NC_GLOBAL {
        String title "MERRA2_GMI tavg1_2d_aer_Nx: 2d,1-Hourly,Time-averaged,Single-Level,Replay,Aerosol Diagnostics";
        String Conventions "COARDS", "GrADS";
        String dataType "Grid";
        String history "Fri Nov 06 10:27:08 EST 2026 : imported by GrADS Data Server 2.0";
        String extra_das_attribute "This is an example of metadata added using a supplementary DAS file. See testdata/extra.das for the source.";
    }
    totexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total aerosol extinction aot [550 nm] ";
    }
    sscmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt column mass density ";
    }
    nicmass25 {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate column mass density [pm2.5] __ensemble__ ";
    }
    var_sufluxvvolc {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sufluxvvolc ";
    }
    so4smassvolc {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 surface mass concentration (volcanic) ";
    }
    bcfluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon column v-wind mass flux __ensemble__ ";
    }
    duexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust extinction aot [550 nm] ";
    }
    pm {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total reconstructed pm ";
    }
    bcexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon extinction aot [550 nm] __ensemble__ ";
    }
    var_dufluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dufluxv ";
    }
    suscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 scattering aot [550 nm] __ensemble__ ";
    }
    ssscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt scattering aot [550 nm] ";
    }
    var_so4smassvol {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4smassvolc ";
    }
    so4cmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column mass density __ensemble__ ";
    }
    ocexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon extinction aot [550 nm] __ensemble__ ";
    }
    var_nh4smass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nh4smass ";
    }
    var_hno3smass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_hno3smass ";
    }
    ssextt25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt extinction aot [550 nm] - pm 2.5 ";
    }
    var_niextt25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_niextt25 ";
    }
    var_sufluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sufluxv ";
    }
    var_duextt25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_duextt25 ";
    }
    var_dufluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dufluxu ";
    }
    var_ducmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ducmass ";
    }
    ssfluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt column v-wind mass flux ";
    }
    var_hno3cmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_hno3cmass ";
    }
    nismass25 {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate surface mass concentration [pm2.5] __ensemble__ ";
    }
    sufluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column v-wind mass flux __ensemble__ ";
    }
    suangstrvolc {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 angstrom parameter [470-870 nm] (volcanic) ";
    }
    ocfluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon column u-wind mass flux __ensemble__ ";
    }
    nifluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate column u-wind mass flux __ensemble__ ";
    }
    bcsmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon surface mass concentration __ensemble__ ";
    }
    var_totexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_totexttau ";
    }
    var_dusmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dusmass ";
    }
    var_bcfluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcfluxv ";
    }
    duextt25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust extinction aot [550 nm] - pm 2.5 ";
    }
    dufluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust column v-wind mass flux ";
    }
    niscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate scattering aot [550 nm] __ensemble__ ";
    }
    totscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total aerosol scattering aot [550 nm] ";
    }
    ocangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon angstrom parameter [470-870 nm] __ensemble__ ";
    }
    suexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 extinction aot [550 nm] __ensemble__ ";
    }
    var_sssmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sssmass ";
    }
    var_duscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_duscatau ";
    }
    var_ducmass25 {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ducmass25 ";
    }
    var_bcscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcscatau ";
    }
    var_nicmass25 {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nicmass25 ";
    }
    var_dusmass25 {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dusmass25 ";
    }
    occmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon column mass density __ensemble__ ";
    }
    nh4cmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ammonium column mass density __ensemble__ ";
    }
    niscat25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate scattering aot [550 nm] - pm 2.5 um __ensemble__ ";
    }
    var_nh4cmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nh4cmass ";
    }
    sufluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column u-wind mass flux __ensemble__ ";
    }
    sssmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt surface mass concentration ";
    }
    ducmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust column mass density ";
    }
    var_niexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_niexttau ";
    }
    ducmass25 {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust column mass density - pm 2.5 ";
    }
    suscatauvolc {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 scattering aot [550 nm] (volcanic) ";
    }
    suexttauvolc {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 extinction aot [550 nm] (volcanic) ";
    }
    var_nismass25 {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nismass25 ";
    }
    var_sufluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sufluxu ";
    }
    var_ssscat25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssscat25 ";
    }
    var_ocangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocangstr ";
    }
    var_ssangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssangstr ";
    }
    var_dmssmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dmssmass ";
    }
    var_sscmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sscmass ";
    }
    var_so2smassvol {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so2smassvolc ";
    }
    var_niscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_niscatau ";
    }
    bcscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon scattering aot [550 nm] __ensemble__ ";
    }
    bcfluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon column u-wind mass flux __ensemble__ ";
    }
    bcangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon angstrom parameter [470-870 nm] __ensemble__ ";
    }
    var_totscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_totscatau ";
    }
    var_nifluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nifluxv ";
    }
    niexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate extinction aot [550 nm] __ensemble__ ";
    }
    dmscmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dms column mass density __ensemble__ ";
    }
    var_ocsmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocsmass ";
    }
    var_bcexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcexttau ";
    }
    ocscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon scattering aot [550 nm] __ensemble__ ";
    }
    var_occmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_occmass ";
    }
    nh3cmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ammonia column mass density __ensemble__ ";
    }
    dmssmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dms surface mass concentration __ensemble__ ";
    }
    niangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate angstrom parameter [470-870 nm] __ensemble__ ";
    }
    var_ocexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocexttau ";
    }
    so2cmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so2 column mass density __ensemble__ ";
    }
    bccmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "black carbon column mass density __ensemble__ ";
    }
    var_nh3smass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nh3smass ";
    }
    var_suexttauvol {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suexttauvolc ";
    }
    so4cmassvolc {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column mass density (volcanic) ";
    }
    dusmass25 {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust surface mass concentration - pm 2.5 ";
    }
    so2smassvolc {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so2 surface mass concentration (volcanic) ";
    }
    var_dmscmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_dmscmass ";
    }
    ssscat25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt scattering aot [550 nm] - pm 2.5 ";
    }
    totangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total aerosol angstrom parameter [470-870 nm] ";
    }
    var_bcsmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcsmass ";
    }
    var_suexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suexttau ";
    }
    nismass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate surface mass concentration __ensemble__ ";
    }
    var_suangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suangstr ";
    }
    var_ssfluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssfluxu ";
    }
    var_so2smass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so2smass ";
    }
    ocsmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon surface mass concentration __ensemble__ ";
    }
    hno3smass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitric acid surface mass concentration __ensemble__ ";
    }
    hno3cmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitric acid column mass density __ensemble__ ";
    }
    var_so4cmassvol {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4cmassvolc ";
    }
    nicmass {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate column mass density __ensemble__ ";
    }
    var_sufluxuvolc {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sufluxuvolc ";
    }
    so4smass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 surface mass concentration __ensemble__ ";
    }
    var_nicmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nicmass ";
    }
    var_sscmass25 {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sscmass25 ";
    }
    var_suscatauvol {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suscatauvolc ";
    }
    var_totangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_totangstr ";
    }
    pm25 {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "total reconstructed pm2.5 ";
    }
    var_nifluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nifluxu ";
    }
    suangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 angstrom parameter [470-870 nm] __ensemble__ ";
    }
    var_pm {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pm ";
    }
    var_bcangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcangstr ";
    }
    duscat25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust scattering aot [550 nm] - pm 2.5 ";
    }
    var_bcfluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bcfluxu ";
    }
    var_suscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suscatau ";
    }
    var_niscat25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_niscat25 ";
    }
    var_so4cmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4cmass ";
    }
    var_nismass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nismass ";
    }
    so2smass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so2 surface mass concentration __ensemble__ ";
    }
    var_ssexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssexttau ";
    }
    var_ocfluxu {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocfluxu ";
    }
    var_niangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_niangstr ";
    }
    nh4smass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ammonium surface mass concentration __ensemble__ ";
    }
    sscmass25 {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt column mass density - pm 2.5 ";
    }
    var_nh3cmass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_nh3cmass ";
    }
    sssmass25 {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt surface mass concentration - pm 2.5 ";
    }
    sufluxuvolc {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column u-wind mass flux (volcanic) ";
    }
    var_ocscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocscatau ";
    }
    ssangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt angstrom parameter [470-870 nm] ";
    }
    var_so4smass {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so4smass ";
    }
    dusmass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust surface mass concentration ";
    }
    duscatau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust scattering aot [550 nm] ";
    }
    var_ssfluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssfluxv ";
    }
    sufluxvvolc {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so4 column v-wind mass flux (volcanic) ";
    }
    duangstr {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust angstrom parameter [470-870 nm] ";
    }
    nh3smass {
        String units "kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "ammonia surface mass concentration __ensemble__ ";
    }
    var_ocfluxv {
        String units "kg m-1 s-1 kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ocfluxv ";
    }
    niextt25 {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate extinction aot [550 nm] - pm 2.5 um __ensemble__ ";
    }
    var_sssmass25 {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_sssmass25 ";
    }
    var_so2cmassvol {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so2cmassvolc ";
    }
    var_ssscatau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssscatau ";
    }
    var_suangstrvol {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_suangstrvolc ";
    }
    var_duangstr {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_duangstr ";
    }
    ssexttau {
        String units "1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt extinction aot [550 nm] ";
    }
    var_duscat25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_duscat25 ";
    }
    var_ssextt25 {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_ssextt25 ";
    }
    ocfluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "organic carbon column v-wind mass flux __ensemble__ ";
    }
    var_duexttau {
        String units "1 1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_duexttau ";
    }
    so2cmassvolc {
        String units "kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "so2 column mass density (volcanic) ";
    }
    var_so2cmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_so2cmass ";
    }
    ssfluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "sea salt column u-wind mass flux ";
    }
    nifluxv {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "nitrate column v-wind mass flux __ensemble__ ";
    }
    dufluxu {
        String units "kg m-1 s-1";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "dust column u-wind mass flux ";
    }
    var_bccmass {
        String units "kg m-2 kg m-2";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_bccmass ";
    }
    var_pm25 {
        String units "kg m-3 kg m-3";
        Float32 _FillValue 1.0E15;
        Float32 missing_value 1.0E15;
        String long_name "variance_of_pm25 ";
    }
    lon {
        String grads_dim "x";
        String grads_mapping "linear";
        String grads_size "576";
        String units "degrees_east";
        String long_name "longitude";
        Float64 minimum -180.00000000000;
        Float64 maximum 179.37500000000;
        Float32 resolution 0.625;
    }
    lat {
        String grads_dim "y";
        String grads_mapping "linear";
        String grads_size "361";
        String units "degrees_north";
        String long_name "latitude";
        Float64 minimum -90.00000000000;
        Float64 maximum 90.00000000000;
        Float32 resolution 0.5;
    }
    time {
        String grads_dim "t";
        String grads_mapping "linear";
        String grads_size "480";
        String grads_min "00z15jan1980";
        String grads_step "1mo";
        String units "days since 1-1-1 00:00:0.0";
        String long_name "time";
        String minimum "00z15jan1980";
        String maximum "00z15dec2019";
        Float32 resolution 30.436325;
    }
}
